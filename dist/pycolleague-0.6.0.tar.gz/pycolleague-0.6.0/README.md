# pycolleague
A module for accessing data exported from Colleague SIS. Includes the ability to work with data exported as CSVs or data imported into the SAS Data Mart or CCDW database.
